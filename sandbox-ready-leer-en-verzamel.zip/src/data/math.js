export const exercises = [
  { id:'r1', sum:'3 + 4', answer:7, distractors:[6,8], level:1 },
  { id:'r2', sum:'9 - 5', answer:4, distractors:[3,5], level:1 },
  { id:'r3', sum:'6 + 2', answer:8, distractors:[7,9], level:1 },
  { id:'r4', sum:'10 - 3', answer:7, distractors:[6,8], level:1 },
  { id:'r5', sum:'12 + 5', answer:17, distractors:[16,18], level:2 },
  { id:'r6', sum:'17 - 9', answer:8, distractors:[7,9], level:2 },
  { id:'r7', sum:'8 + 9', answer:17, distractors:[16,18], level:2 },
  { id:'r8', sum:'5 × 2', answer:10, distractors:[8,12], level:3 },
  { id:'r9', sum:'10 × 2', answer:20, distractors:[15,25], level:3 },
  { id:'r10', sum:'5 × 5', answer:25, distractors:[20,30], level:3 }
]
